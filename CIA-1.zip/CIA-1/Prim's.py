vertices = 10
graph = [[0, 1, 2, 3, 4],[5, 6, 7, 8, 9],[10, 11, 12, 13, 14],[15, 16, 17, 18, 19],[20, 21, 22, 23, 24]]
selected = [0, 0, 0, 0, 0]
edge = 0
selected[0] = True
print("Edge : Weight\n")
while (edge < V - 1):
    minimum = 1000
    x = 0
    y = 0
    for i in range(vertices):
        if selected[i]:
            for j in range(vertices):
                if ((not selected[j]) and graph[i][j]):  
                    if minimum > graph[i][j]:
                        minimum = graph[i][j]
                        x = i
                        y = j
    print((x) + "-" + (y) + ":" + (graph[x][y]))
    selected[y] = True
    edge += 1