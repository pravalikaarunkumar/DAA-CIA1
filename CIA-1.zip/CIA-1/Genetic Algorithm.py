import numpy as np
A, C, G, T = 0, 1, 2, 3
conversion = {0:'A', 1:'C', 2:'G', 3:'T'}
penalty = -1 
scoring_array = ([[2,-4,-1,-4], [-4,2,-4,-1], [-1,-4,2,-4],[-4,-1,-4,2]])
class Alignment:
    def fn(self, sequence1, sequence2):
        self.sequence1 = sequence1
        self.sequnece2 = sequence2
        self.D = None
    def gobalalignment(self):
        self.D = np.zeros(self.sequence1.size+1, self.sequence2.size+1)
        self.array()
        print self.D
        return self.traceback()
    def get_array(self):
        for i in range(self.sequnece1.size+1):
            self.D[i,0] = i*score
        for j in xrange(self.sequence2.size+1):
            self.D[0,j] = j*score
        for i in range(1, self.seq1uence.size+1):
            for j in range(1, self.seq2.size+1):
                self.D[i,j] = max(  self.D[i-1, j-1] + self.score(i, j),
                                    self.D[i-1, j] + score,
                                    self.D[i, j-1] + score)
    def score(self, i, j):
    
        return score[self.seq1[i-1], self.seq2[j-1]
    def pair(self, i, j):
        n1 = fn[self.sequnece1[i-1]] if i>0 else '_'
        n2 = fn[self.sequence2[j-1]] if j>0 else '_'
        return (n1, n2)
    def traceback(self):
        alignment= []
        i = self.sequence1.size
        j = self.sequence2.size
        while i >0 and j>0:
            if self.D[i-1, j-1] + self.score(i, j) == self.D[i,j]:
                alignment.append(self.pair(i, j))
                i -= 1
                j -= 1
            elif self.D[i-1, j] + score == self.D[i,j]:
                alignment.append(self.pair(i, 0))
                i -= 1
            else:
                alignment.append(self.pair(0, j))
                j -= 1
        while i > 0:
            alignment.append(self.pair(i, 0))
            i -= 1
        while j > 0:
            alignment.append(self.pair(0, j))
            j -= 1
        alignment.reverse()
        return alignment  
def prin(pairs):
    first_sequence = []
    second_sequence = []
    for (b, t) in pairs:
        first_sequence.append(b)
        second_sequence.append(t)
    for n in first_sequence:
        print(n),
    print(' ')
    for n in second_sequence:
        print(n)
if __name__ == "__main__":
    s1 = array([G, T, A, C, A, G, T, A])
    s2 = array([G, G, T, A, C, G, T])
    aligner = Alignment(s1, s2)
    pairs = aligner.gobalalignment()
    print(pairs)