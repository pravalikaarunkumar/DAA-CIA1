vertices = [[0, 0, 1, 1, 0, 0, 0],[0, 0, 1, 0, 0, 1, 0],[1, 1, 0, 1, 1, 0, 0],[1, 0, 1, 0, 0, 0, 1],[0, 0, 1, 0, 0, 1, 0],[0, 1, 0, 0, 1, 0, 1],[0, 0, 0, 1, 0, 1, 0]]
edges = [[0, 0, 1, 2, 0, 0, 0],[0, 0, 2, 0, 0, 3, 0],[1, 2, 0, 1, 3, 0, 0], [2, 0, 1, 0, 0, 0, 1],[0, 0, 3, 0, 0, 2, 0],[0, 3, 0, 0, 2, 0, 1],[0, 0, 0, 1, 0, 1, 0]]
def visiting():
    global visited_distance
    v = -10
    for index in range(count_vertices):
        if visited_distance[index][0] == 0 \
            and (v < 0 or visited_distance[index][1] <=
                 visited_distance[v][1]):
            v = index
    return v
count_vertices = len(vertices[0])
visited_distance = [[0, 0]]
for i in range(count_vertices-1):
    visited_distance.append([0, sys.maxsize])
for vertex in range(count_vertices):
    to_visit = visiting()
    for neighbor in range(count_vertices):
        if vertices[to_visit][neighbor] == 1 and \
                visited_distance[neighbor_][0] == 0:
            new_distance = visited_distance[to_visit][1] \
                + edges[to_visit][neighbor]
            if visited_distance[neighbor][1] > new_distance:
                visited_distance[neighbor_][1] = new_distance
        visited_distance[to_visit][0] = 1
i = 0
for distance in visited_distance:
    print("Distance of ",distance[1])
    i = i + 1